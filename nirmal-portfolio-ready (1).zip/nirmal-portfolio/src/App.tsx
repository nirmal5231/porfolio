import React, { useState, useEffect, useRef } from 'react';
import { ArrowDown, ArrowRight, ExternalLink, X, Plus, Play, Info } from 'lucide-react';

// ============================================================================
// 🛠️ DEVELOPER CONFIGURATION AREA (DATA HUB) 🛠️
// ============================================================================
// Replace the Unsplash URLs below with your own image paths or hosting links.
// (e.g., "/assets/my-photo.png" or "https://imgur.com/your-image-link.jpg")
// All text, projects, and images on the website pull from this single object.
// ============================================================================

const portfolioData = {
  profile: {
    name: "Nirmal",
    lastName: "Kumar",
    roles: "CSE (IoT) • Developer • Creator",
    tagline: "Building, learning and turning ideas into something real.",
    email: "hello@nirmal.dev",
    github: "#",
    linkedin: "#",
    
    // --- 🖼️ MAIN PROFILE IMAGES ---
    heroImage: "https://images.unsplash.com/photo-1607799279861-4dd97b876e4d?q=80&w=2000&auto=format&fit=crop", // Large background at the top
    dpImage: "https://images.unsplash.com/photo-1618077360395-f3068be8e001?q=80&w=400&auto=format&fit=crop",   // Small glowing avatar
    aboutImage: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=1200&auto=format&fit=crop", // FIX: Replaced with a fresh, working placeholder URL
    
    aboutStatement: "CURIOUS ABOUT TECHNOLOGY. OBSESSED WITH LEARNING. ALWAYS BUILDING.",
    aboutText: "I am a Computer Science engineering student specializing in IoT, passionate about bridging the gap between hardware and software. I love building practical projects, experimenting with new technologies, and constantly expanding my technical horizons.",
    field: "Computer Science & Engineering",
    specialization: "Internet of Things (IoT)",
    current: "B.Tech Student",
    focus: "Technology • Programming • Projects"
  },
  
  // --- 🛣️ JOURNEY IMAGES ---
  journey: [
    { id: 1, year: "2020", stage: "The Beginning", desc: "Completed 12th grade with a growing fascination for computers.", image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?q=80&w=800&auto=format&fit=crop" },
    { id: 2, year: "2021", stage: "First Steps", desc: "Started Diploma, writing my first lines of code and understanding logic.", image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=800&auto=format&fit=crop" },
    { id: 3, year: "2023", stage: "Advancing", desc: "Transitioned to B.Tech through Lateral Entry, expanding my technical foundation.", image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=800&auto=format&fit=crop" },
    { id: 4, year: "2024", stage: "Specializing", desc: "Diving deep into CSE with a focus on Internet of Things (IoT).", image: "https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=800&auto=format&fit=crop" },
    { id: 5, year: "2025", stage: "Building", desc: "Creating practical projects, applying hardware-software integration.", image: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?q=80&w=800&auto=format&fit=crop" },
    { id: 6, year: "Future", stage: "Innovation", desc: "Continuing to learn, build, and explore the edges of technology.", image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=800&auto=format&fit=crop" }
  ],
  
  skills: [
    { name: "C", size: "text-4xl md:text-6xl" },
    { name: "C++", size: "text-6xl md:text-8xl text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400" },
    { name: "Java", size: "text-5xl md:text-7xl" },
    { name: "Python", size: "text-7xl md:text-9xl text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-yellow-400" },
    { name: "HTML", size: "text-3xl md:text-5xl" },
    { name: "CSS", size: "text-3xl md:text-5xl" },
    { name: "JavaScript", size: "text-6xl md:text-8xl text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-amber-500" },
    { name: "IoT", size: "text-8xl md:text-[10rem] text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 font-bold" },
    { name: "Git", size: "text-4xl md:text-6xl" },
    { name: "GitHub", size: "text-5xl md:text-7xl" }
  ],
  
  // --- 🔬 LEARNING TOOLTIP IMAGES ---
  learning: [
    { topic: "Java", desc: "Deepening understanding of object-oriented principles and enterprise patterns.", img: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?q=80&w=400&auto=format&fit=crop" },
    { topic: "Python", desc: "Exploring automation, data processing, and scripting.", img: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=400&auto=format&fit=crop" },
    { topic: "DSA", desc: "Strengthening problem-solving skills and algorithmic thinking.", img: "https://images.unsplash.com/photo-1509228627152-72ae9ae6848d?q=80&w=400&auto=format&fit=crop" },
    { topic: "Web Development", desc: "Building responsive and interactive user interfaces.", img: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=400&auto=format&fit=crop" },
    { topic: "IoT", desc: "Connecting physical devices to the cloud and managing sensor data.", img: "https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=400&auto=format&fit=crop" }
  ],
  
  // --- 🚀 PROJECT IMAGES ---
  projects: [
    {
      id: "smartgate",
      title: "SMARTGATE",
      subtitle: "IoT Security Ecosystem",
      cover: "https://images.unsplash.com/photo-1558346490-a72e53ae2d4f?q=80&w=1600&auto=format&fit=crop", // Main Project Cover
      story: {
        overview: "[Placeholder] SmartGate is an automated entry management system utilizing IoT sensors to authenticate and log access securely.",
        problem: "[Placeholder] Traditional gate management is slow, relies on manual entry, and lacks real-time monitoring.",
        idea: {
          text: "[Placeholder] Replace manual logbooks with a connected sensor array that authenticates users and syncs with a central database.",
          image: "https://images.unsplash.com/photo-1523961131990-5ea7c61b2107?q=80&w=1200&auto=format&fit=crop" // Idea visual
        },
        tech: ["C++", "IoT", "Microcontrollers", "Sensors", "WiFi Module"],
        features: [
          "[Placeholder] Real-time Authentication",
          "[Placeholder] Cloud Data Logging",
          "[Placeholder] Remote Access Control"
        ],
        architecture: {
          text: "[Placeholder] Hardware sensors -> Microcontroller -> Cloud Database -> Web Dashboard",
          image: "https://images.unsplash.com/photo-1555664424-778a1e5e1b48?q=80&w=1200&auto=format&fit=crop" // Architecture diagram
        },
        // Screenshots array for the masonry gallery inside the project modal
        screenshots: [
          "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1200&auto=format&fit=crop",
          "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=800&auto=format&fit=crop",
          "https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=800&auto=format&fit=crop"
        ],
        learning: "[Placeholder] Integrating hardware with software requires careful timing management and handling network instability gracefully.",
        github: "#",
        demo: "#"
      }
    }
  ],
  
  // --- 📜 CERTIFICATE IMAGES ---
  certificates: [
    { id: 1, title: "[Placeholder] IoT Fundamentals", issuer: "Cisco Networking Academy", date: "Jan 2024", image: "https://images.unsplash.com/photo-1589330694653-afaae7a243ae?q=80&w=800&auto=format&fit=crop" },
    { id: 2, title: "[Placeholder] Python Basics", issuer: "Coursera", date: "Mar 2023", image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?q=80&w=800&auto=format&fit=crop" },
    { id: 3, title: "[Placeholder] Web Development", issuer: "Udemy", date: "Aug 2023", image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=800&auto=format&fit=crop" }
  ],
  
  // --- 🏆 ACHIEVEMENT IMAGES ---
  achievements: [
    { id: 1, title: "[Placeholder] Hackathon Winner", desc: "Secured first place in the college IoT innovation challenge by building a smart environment monitor.", date: "2024", image: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?q=80&w=1200&auto=format&fit=crop" },
    { id: 2, title: "[Placeholder] Tech Fest Coordinator", desc: "Led the technical team for our annual college symposium.", date: "2023", image: "https://images.unsplash.com/photo-1515187029135-18ee286d815b?q=80&w=1200&auto=format&fit=crop" }
  ],
  
  // --- 📸 GALLERY IMAGES ---
  gallery: [
    { img: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?q=80&w=800&auto=format&fit=crop", span: "md:col-span-2 md:row-span-2", caption: "Workspace" },
    { img: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=800&auto=format&fit=crop", span: "md:col-span-1 md:row-span-1", caption: "Code" },
    { img: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=800&auto=format&fit=crop", span: "md:col-span-1 md:row-span-2", caption: "Details" },
    { img: "https://images.unsplash.com/photo-1555664424-778a1e5e1b48?q=80&w=800&auto=format&fit=crop", span: "md:col-span-1 md:row-span-1", caption: "Hardware" },
    { img: "https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=800&auto=format&fit=crop", span: "md:col-span-1 md:row-span-1", caption: "Components" }
  ]
};

const injectGlobalStyles = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Anton&family=Inter:wght@300;400;500;600&display=swap');

    :root {
      --cursor-size: 12px;
      --theme-bg: #0d0614;
      --theme-text: #ffffff;
      --theme-accent: #d946ef;
      --theme-accent-2: #3b82f6;
    }
    
    body {
      font-family: 'Inter', sans-serif;
      margin: 0;
      padding: 0;
      overflow-x: hidden;
      background-color: var(--theme-bg);
      color: var(--theme-text);
      transition: background-color 1s ease-out, color 1s ease-out;
    }

    /* Custom Cursor hiding default */
    @media (pointer: fine) {
      body { cursor: none; }
      a, button { cursor: none; }
    }

    h1, h2, h3, h4, h5, .font-display {
      font-family: 'Anton', sans-serif;
      text-transform: uppercase;
      letter-spacing: 0.02em;
    }

    /* Cinematic Color Themes - Enhanced for Vibrancy */
    body[data-theme="hero"] { --theme-bg: #0f0720; --theme-text: #ffffff; --theme-accent: #ec4899; --theme-accent-2: #8b5cf6; }
    body[data-theme="about"] { --theme-bg: #fcfbf9; --theme-text: #0f172a; --theme-accent: #6366f1; --theme-accent-2: #a855f7; }
    body[data-theme="journey"] { --theme-bg: #041421; --theme-text: #f0f9ff; --theme-accent: #06b6d4; --theme-accent-2: #3b82f6; }
    body[data-theme="projects"] { --theme-bg: #1a082b; --theme-text: #faf5ff; --theme-accent: #d946ef; --theme-accent-2: #0ea5e9; }
    body[data-theme="skills"] { --theme-bg: #ffffff; --theme-text: #020617; --theme-accent: #10b981; --theme-accent-2: #0ea5e9; }
    body[data-theme="archive"] { --theme-bg: #0f0a1c; --theme-text: #ffffff; --theme-accent: #8b5cf6; --theme-accent-2: #f43f5e; }
    body[data-theme="gallery"] { --theme-bg: #0a0a0a; --theme-text: #ffffff; --theme-accent: #f59e0b; --theme-accent-2: #ef4444; }
    body[data-theme="contact"] { --theme-bg: #140510; --theme-text: #ffffff; --theme-accent: #f97316; --theme-accent-2: #db2777; }

    /* Animated Gradient Background for Contact */
    .bg-animated-gradient {
      background: linear-gradient(-45deg, #f97316, #db2777, #8b5cf6, #3b82f6);
      background-size: 400% 400%;
      animation: gradientBG 15s ease infinite;
    }
    @keyframes gradientBG {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    /* Realistic Neon Flicker for Hero Name */
    @keyframes cinematicFlicker {
      0% { opacity: 0; text-shadow: none; }
      5% { opacity: 0; text-shadow: none; }
      6% { opacity: 1; text-shadow: 0 0 30px rgba(255,255,255,1); }
      7% { opacity: 0; text-shadow: none; }
      8% { opacity: 1; text-shadow: 0 0 30px rgba(255,255,255,1); }
      9% { opacity: 0; text-shadow: none; }
      20% { opacity: 0; text-shadow: none; }
      21% { opacity: 1; text-shadow: 0 0 40px rgba(255,255,255,0.8); }
      25% { opacity: 0.5; text-shadow: 0 0 10px rgba(255,255,255,0.2); }
      30% { opacity: 1; text-shadow: 0 0 30px rgba(255,255,255,0.6); }
      100% { opacity: 1; text-shadow: 0 0 15px rgba(255,255,255,0.3); }
    }

    @keyframes slideUpFade {
      from { transform: translateY(40px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }

    /* Custom Cursor styles */
    #custom-cursor {
      position: fixed;
      top: 0;
      left: 0;
      width: var(--cursor-size);
      height: var(--cursor-size);
      background-color: var(--theme-accent);
      border-radius: 50%;
      pointer-events: none;
      z-index: 9999;
      transform: translate(-50%, -50%);
      transition: width 0.3s cubic-bezier(0.16, 1, 0.3, 1), 
                  height 0.3s cubic-bezier(0.16, 1, 0.3, 1), 
                  background-color 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Inter', sans-serif;
      font-size: 12px;
      font-weight: 600;
      color: #ffffff;
      text-align: center;
      opacity: 0;
      mix-blend-mode: normal;
      box-shadow: 0 0 15px var(--theme-accent);
    }
    
    @media (hover: none) {
      #custom-cursor { display: none !important; }
      body, a, button { cursor: auto !important; }
    }

    #custom-cursor.hovering-text {
      width: 80px;
      height: 80px;
      background-color: var(--theme-accent);
      border: none;
    }
    
    #custom-cursor.hovering-link {
      width: 40px;
      height: 40px;
      background-color: transparent;
      border: 1px solid var(--theme-accent);
      box-shadow: inset 0 0 10px var(--theme-accent), 0 0 10px var(--theme-accent);
    }

    /* Scroll Reveal & Typography Animations */
    .reveal {
      opacity: 0;
      transform: translateY(40px);
      transition: all 1s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .reveal.active {
      opacity: 1;
      transform: translateY(0);
    }
    
    .reveal-text {
      clip-path: polygon(0 100%, 100% 100%, 100% 100%, 0% 100%);
      transition: clip-path 1.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .reveal.active .reveal-text {
      clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);
    }

    /* Images */
    .img-zoom {
      transition: transform 1.5s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .img-container:hover .img-zoom {
      transform: scale(1.03);
    }

    /* Journey Horizontal Scroll */
    .h-scroll-container {
      height: 400vh;
      position: relative;
    }
    .h-scroll-sticky {
      position: sticky;
      top: 0;
      height: 100vh;
      display: flex;
      align-items: center;
      overflow: hidden;
    }

    /* Hide Scrollbar */
    ::-webkit-scrollbar { display: none; }
    * { -ms-overflow-style: none; scrollbar-width: none; }

    /* Grain Texture Overlay */
    .noise-overlay {
      position: fixed;
      top: 0; left: 0; width: 100vw; height: 100vh;
      pointer-events: none;
      z-index: 9998;
      opacity: 0.03;
      background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");
    }

    /* Subtle text outline */
    .text-outline {
      color: transparent;
      -webkit-text-stroke: 1px currentColor;
    }
    
    .nav-blend {
      mix-blend-mode: difference;
      color: white;
    }
  `}</style>
);

const useMousePosition = () => {
  const [mousePosition, setMousePosition] = useState({ x: null, y: null });
  useEffect(() => {
    const updateMousePosition = ev => setMousePosition({ x: ev.clientX, y: ev.clientY });
    window.addEventListener('mousemove', updateMousePosition);
    return () => window.removeEventListener('mousemove', updateMousePosition);
  }, []);
  return mousePosition;
};

const useScrollReveal = () => {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

    document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
};

const useThemeObserver = () => {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && entry.intersectionRatio >= 0.3) {
          const theme = entry.target.getAttribute('data-theme');
          if (theme) document.body.setAttribute('data-theme', theme);
        }
      });
    }, { threshold: [0.3] });

    document.querySelectorAll('.section-marker').forEach(section => observer.observe(section));
    return () => observer.disconnect();
  }, []);
};

const Cursor = () => {
  const { x, y } = useMousePosition();
  const cursorRef = useRef(null);
  const [text, setText] = useState("");
  const [mode, setMode] = useState(""); // text, link, null

  useEffect(() => {
    if (!cursorRef.current || x === null) return;
    cursorRef.current.style.transform = `translate(${x}px, ${y}px) translate(-50%, -50%)`;
    cursorRef.current.style.opacity = 1;

    const handleMouseOver = (e) => {
      const target = e.target.closest('[data-cursor], a, button');
      if (target) {
        if (target.dataset.cursor) {
          setText(target.dataset.cursor);
          setMode("text");
        } else {
          setText("");
          setMode("link");
        }
      } else {
        setText("");
        setMode("");
      }
    };

    document.addEventListener('mouseover', handleMouseOver);
    return () => document.removeEventListener('mouseover', handleMouseOver);
  }, [x, y]);

  return (
    <div 
      id="custom-cursor" 
      ref={cursorRef} 
      className={mode === "text" ? "hovering-text" : mode === "link" ? "hovering-link" : ""}
    >
      {text}
    </div>
  );
};

const CinematicIntro = ({ onComplete }) => {
  return (
    <div className="fixed inset-0 z-[100] bg-[#0a0510] flex flex-col items-center justify-center animate-[fadeOut_1s_ease-in-out_2s_both]" onAnimationEnd={onComplete}>
      <h1 className="text-4xl md:text-6xl font-display text-white tracking-widest mb-4 animate-[fadeIn_1s_ease-out]">
        NIRMAL KUMAR
      </h1>
      <p className="text-xs font-mono tracking-widest text-gray-400 uppercase animate-[fadeIn_1s_ease-out_0.5s_both]">
        {portfolioData.profile.roles}
      </p>
      <button 
        onClick={onComplete}
        className="absolute bottom-12 text-xs font-mono tracking-widest text-gray-500 hover:text-white transition-colors animate-[fadeIn_1s_ease-out_1s_both]"
      >
        SKIP INTRO &rarr;
      </button>
    </div>
  );
};

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <nav className="fixed top-0 w-full z-50 p-6 flex justify-between items-center nav-blend pointer-events-none">
        <div className="font-display text-2xl tracking-widest pointer-events-auto">NIRMAL.</div>
        
        {/* Desktop Nav */}
        <div className="hidden md:flex gap-8 text-xs font-bold tracking-widest uppercase pointer-events-auto">
          {['About', 'Journey', 'Projects', 'Gallery', 'Contact'].map(item => (
            <a key={item} href={`#${item.toLowerCase()}`} className="hover:line-through transition-all">{item}</a>
          ))}
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden pointer-events-auto p-2" onClick={() => setIsOpen(true)}>
          <Plus size={24} />
        </button>
      </nav>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="fixed inset-0 bg-black z-[200] flex flex-col p-6 animate-in fade-in duration-300 text-white">
          <div className="flex justify-between items-center mb-16">
            <div className="font-display text-2xl tracking-widest">NIRMAL.</div>
            <button onClick={() => setIsOpen(false)} className="p-2"><X size={24}/></button>
          </div>
          <div className="flex flex-col gap-8 text-4xl font-display tracking-wider">
             {['About', 'Journey', 'Projects', 'Gallery', 'Contact'].map(item => (
              <a key={item} href={`#${item.toLowerCase()}`} onClick={() => setIsOpen(false)} className="hover:text-purple-400 transition-colors">
                {item}
              </a>
            ))}
          </div>
        </div>
      )}
    </>
  );
};

const HeroSection = () => {
  return (
    <section id="hero" data-theme="hero" className="relative h-screen w-full flex flex-col justify-end section-marker overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img 
          src={portfolioData.profile.heroImage} 
          alt="Nirmal Kumar" 
          className="w-full h-full object-cover opacity-60 scale-105 animate-[slowZoom_20s_linear_infinite_alternate]" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[var(--theme-bg)] via-[var(--theme-bg)]/40 to-transparent opacity-100"></div>
        {/* Subtle colorful glow behind hero text */}
        <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-pink-600/20 blur-[120px] rounded-full mix-blend-screen pointer-events-none animate-[pulse_4s_infinite_alternate]"></div>
        <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-purple-600/20 blur-[120px] rounded-full mix-blend-screen pointer-events-none animate-[pulse_5s_infinite_alternate_reverse]"></div>
      </div>
      
      <div className="relative z-10 w-full max-w-[1400px] mx-auto px-6 md:px-12 pb-24 md:pb-32">
        <div className="overflow-hidden flex flex-col md:flex-row md:items-end justify-between gap-8">
          <h1 className="text-[18vw] md:text-[11vw] font-display leading-[0.8] text-white mix-blend-overlay flex flex-col gap-4 md:gap-6">
            <span className="inline-block animate-[cinematicFlicker_1.5s_linear_0.2s_both]">NIRMAL</span>
            <span className="inline-block animate-[cinematicFlicker_2s_linear_0.6s_both]">KUMAR</span>
          </h1>
          
          <div className="md:pb-6 animate-[slideUpFade_1.5s_ease-out_1s_both]">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6 md:gap-10 mb-4 mt-6 md:mt-0">
              
              {/* Unique DP Container - Made Larger & Better Aligned */}
              <div className="relative w-32 h-32 md:w-44 md:h-44 shrink-0 rounded-full group shadow-[0_0_40px_rgba(217,70,239,0.4)] cursor-pointer" data-cursor="MY DP">
                {/* Rotating gradient border */}
                <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-cyan-400 via-fuchsia-500 to-amber-400 animate-[spin_4s_linear_infinite] group-hover:animate-[spin_2s_linear_infinite]"></div>
                {/* Inner image container */}
                <div className="absolute inset-[3px] md:inset-[4px] rounded-full overflow-hidden bg-[#0d0614]">
                  <img 
                    src={portfolioData.profile.dpImage} 
                    alt="Profile DP" 
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500 scale-110 group-hover:scale-100" 
                  />
                </div>
                {/* Online Status Dot */}
                <div className="absolute bottom-2 right-2 md:bottom-4 md:right-4 w-5 h-5 md:w-7 md:h-7 bg-emerald-400 border-[3px] border-[#0d0614] rounded-full animate-pulse shadow-[0_0_20px_rgba(52,211,153,0.9)] z-10"></div>
              </div>
              
              {/* Bio Texts */}
              <div className="flex flex-col justify-center">
                <p className="text-sm md:text-lg font-bold tracking-widest uppercase mb-3 text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-400 drop-shadow-md">
                  {portfolioData.profile.roles}
                </p>
                <p className="text-xs md:text-sm font-mono tracking-widest text-gray-300 max-w-[280px] md:max-w-[320px] leading-relaxed uppercase border-l-2 border-pink-500/50 pl-4 shadow-sm">
                  {portfolioData.profile.tagline}
                </p>
              </div>

            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-6 md:left-12 flex gap-6 z-20 animate-[fadeIn_2s_ease-out_1.5s_both]">
        <a href="#projects" className="flex items-center gap-2 text-xs font-bold tracking-widest uppercase hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-cyan-400 hover:to-blue-500 transition-all">
          Explore My Work <ArrowDown size={14} className="text-current" />
        </a>
        <a href="#" className="flex items-center gap-2 text-xs font-bold tracking-widest uppercase hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-pink-400 hover:to-orange-400 transition-all text-gray-400">
          Download Resume
        </a>
      </div>
    </section>
  );
};

const AboutSection = () => {
  return (
    <section id="about" data-theme="about" className="py-32 md:py-48 px-6 md:px-12 section-marker overflow-hidden border-t border-black/5 relative">
       {/* Colorful accents in light mode */}
       <div className="absolute top-0 right-0 w-[40vw] h-[40vw] bg-indigo-500/5 blur-[100px] rounded-full pointer-events-none"></div>
       <div className="absolute bottom-0 left-0 w-[30vw] h-[30vw] bg-purple-500/5 blur-[100px] rounded-full pointer-events-none"></div>

      <div className="max-w-[1400px] mx-auto relative z-10">
        <div className="grid lg:grid-cols-12 gap-16 lg:gap-8 items-center">
          
          <div className="lg:col-span-7 reveal">
            <span className="text-xs font-bold tracking-widest uppercase mb-12 block text-[var(--theme-accent)]">01 — About Me</span>
            <h2 className="text-4xl md:text-6xl font-display leading-[1.1] mb-12 reveal-text">
              {portfolioData.profile.aboutStatement.split('. ').map((sentence, i) => (
                <React.Fragment key={i}>
                  <span className={i === 1 ? "text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 to-purple-500 drop-shadow-sm" : ""}>
                    {sentence}{i !== 2 && '.'}
                  </span><br/>
                </React.Fragment>
              ))}
            </h2>
            <div className="max-w-xl">
              <p className="text-lg md:text-xl font-light leading-relaxed opacity-90 mb-12 text-slate-700">
                {portfolioData.profile.aboutText}
              </p>
              
              <div className="grid grid-cols-2 gap-y-8 gap-x-4 border-t border-slate-200 pt-8 opacity-90 text-slate-800">
                <div>
                  <span className="text-[10px] font-mono tracking-widest uppercase block mb-1 text-[var(--theme-accent-2)]">Field</span>
                  <span className="font-bold text-sm">{portfolioData.profile.field}</span>
                </div>
                <div>
                  <span className="text-[10px] font-mono tracking-widest uppercase block mb-1 text-[var(--theme-accent-2)]">Specialization</span>
                  <span className="font-bold text-sm">{portfolioData.profile.specialization}</span>
                </div>
                <div>
                  <span className="text-[10px] font-mono tracking-widest uppercase block mb-1 text-[var(--theme-accent-2)]">Current</span>
                  <span className="font-bold text-sm">{portfolioData.profile.current}</span>
                </div>
                <div>
                  <span className="text-[10px] font-mono tracking-widest uppercase block mb-1 text-[var(--theme-accent-2)]">Focus</span>
                  <span className="font-bold text-sm">{portfolioData.profile.focus}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 relative reveal">
            {/* Added bg-slate-200 to the container as a loading fallback */}
            <div className="aspect-[3/4] overflow-hidden bg-slate-200 img-container rounded-sm shadow-[0_20px_50px_rgba(99,102,241,0.15)] hover:shadow-[0_20px_60px_rgba(99,102,241,0.25)] transition-shadow duration-500 border border-slate-100 relative group">
              <img 
                src={portfolioData.profile.aboutImage} 
                alt="About Nirmal" 
                className="w-full h-full object-cover img-zoom" 
                data-cursor="WHO AM I"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/20 to-purple-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
            </div>
            {/* Decorative element */}
            <div className="absolute -bottom-10 -left-10 text-[10rem] font-display text-outline opacity-5 pointer-events-none hidden md:block text-[var(--theme-accent)]">
              NK
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
};

const JourneySection = () => {
  const containerRef = useRef(null);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    if (isMobile) return;
    const handleScroll = () => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const scrollableHeight = rect.height - window.innerHeight;
      const scrolled = -rect.top;
      
      if (scrolled >= 0 && scrolled <= scrollableHeight) {
        setScrollProgress(scrolled / scrollableHeight);
      } else if (scrolled < 0) {
        setScrollProgress(0);
      } else {
        setScrollProgress(1);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isMobile]);

  if (isMobile) {
    // Vertical layout for mobile with colorful accents
    return (
      <section id="journey" data-theme="journey" className="py-32 px-6 section-marker overflow-hidden relative">
        <span className="text-xs font-bold tracking-widest uppercase mb-16 block text-[var(--theme-accent)] reveal">02 — My Journey</span>
        <div className="space-y-20 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-[var(--theme-accent)] before:via-[var(--theme-accent-2)] before:to-transparent">
          {portfolioData.journey.map((item, index) => (
            <div key={item.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active reveal">
              <div className="flex items-center justify-center w-10 h-10 rounded-full border border-cyan-500/30 bg-[var(--theme-bg)] text-xs font-mono shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow-[0_0_15px_rgba(6,182,212,0.3)] z-10 text-cyan-300">
                {String(index + 1).padStart(2, '0')}
              </div>
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] pl-4 md:pl-0">
                <div className="text-xs font-mono tracking-widest text-cyan-400 mb-2">{item.year}</div>
                <h3 className="text-3xl font-display mb-2 text-white">{item.stage}</h3>
                <p className="text-sm font-light opacity-80 mb-4">{item.desc}</p>
                <div className="aspect-video overflow-hidden border border-cyan-500/20 rounded-sm relative">
                  <img src={item.image} alt={item.stage} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-blue-500/10 mix-blend-overlay"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  return (
    <section id="journey" data-theme="journey" ref={containerRef} className="h-scroll-container section-marker">
      <div className="h-scroll-sticky">
        
        {/* Background Typography */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
          <h2 className="text-[40vw] font-display whitespace-nowrap leading-none text-cyan-500" style={{ transform: `translateX(-${scrollProgress * 30}%)`}}>
            THE JOURNEY
          </h2>
        </div>

        <div className="absolute top-12 left-12 z-10">
           <span className="text-xs font-bold tracking-widest uppercase text-[var(--theme-accent)] drop-shadow-[0_0_10px_rgba(6,182,212,0.5)]">02 — My Journey</span>
        </div>

        {/* Track */}
        <div 
          className="flex gap-32 px-32 items-center min-w-max transition-transform duration-75 ease-linear"
          style={{ transform: `translateX(-${scrollProgress * (portfolioData.journey.length * 40)}vw)` }}
        >
          {portfolioData.journey.map((item, index) => (
            <div key={item.id} className="w-[45vw] lg:w-[35vw] shrink-0 group">
              <div className="relative aspect-[16/10] overflow-hidden rounded-sm mb-8 img-container shadow-lg">
                <img src={item.image} alt={item.stage} className="w-full h-full object-cover img-zoom grayscale group-hover:grayscale-0 transition-all duration-700" />
                <div className="absolute inset-0 border border-cyan-500/0 group-hover:border-cyan-500/30 group-hover:shadow-[inset_0_0_30px_rgba(6,182,212,0.2)] bg-gradient-to-t from-blue-900/40 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-700 pointer-events-none rounded-sm"></div>
              </div>
              
              <div className="grid grid-cols-12 gap-4">
                <div className="col-span-3 text-sm font-mono tracking-widest text-cyan-400 border-t border-cyan-500/30 pt-4">
                  {item.year}
                </div>
                <div className="col-span-9 border-t border-cyan-500/30 pt-4">
                  <h3 className="text-4xl font-display mb-3 text-white group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-cyan-400 group-hover:to-blue-400 transition-colors">{item.stage}</h3>
                  <p className="font-light opacity-90 text-lg max-w-md text-slate-300">{item.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const ProjectCaseStudy = ({ project, onClose }) => {
  if (!project) return null;

  return (
    <div className="fixed inset-0 bg-[#0c0514] text-white z-[200] overflow-y-auto w-full h-full animate-in fade-in slide-in-from-bottom-10 duration-700">
      
      {/* Sticky Header */}
      <div className="sticky top-0 w-full z-50 flex justify-between items-center px-6 md:px-12 py-8 mix-blend-difference pointer-events-none">
        <span className="font-display tracking-widest pointer-events-auto text-transparent bg-clip-text bg-gradient-to-r from-magenta-400 to-blue-400">CASE STUDY</span>
        <button onClick={onClose} className="p-2 pointer-events-auto transition-transform hover:rotate-90 text-white hover:text-magenta-400" data-cursor="CLOSE">
          <X size={32} />
        </button>
      </div>

      <div className="w-full pb-32">
        {/* Cover */}
        <div className="h-screen w-full relative flex items-center justify-center p-6 md:p-12 mb-24 overflow-hidden">
          <div className="absolute inset-0">
             <img src={project.cover} className="w-full h-full object-cover opacity-30 scale-105 animate-[slowZoom_10s_ease-out_forwards]" alt="Cover" />
             <div className="absolute inset-0 bg-gradient-to-b from-[#0c0514]/50 via-transparent to-[#0c0514]"></div>
             <div className="absolute inset-0 bg-magenta-900/20 mix-blend-overlay"></div>
          </div>
          <div className="relative z-10 max-w-[1400px] w-full mx-auto mt-24">
            <span className="text-sm font-mono tracking-widest uppercase mb-6 block text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-400 to-cyan-400">01 — Overview</span>
            <h1 className="text-[12vw] md:text-[10rem] font-display leading-[0.8] mb-8 drop-shadow-[0_0_40px_rgba(232,28,255,0.4)]">{project.title}</h1>
            <div className="grid md:grid-cols-2 gap-12">
              <p className="text-2xl md:text-4xl font-light font-display opacity-90 text-fuchsia-100">{project.subtitle}</p>
              <p className="text-lg font-light opacity-80 leading-relaxed border-l border-fuchsia-500/30 pl-6 text-slate-200">{project.story.overview}</p>
            </div>
          </div>
        </div>

        {/* Content Flow */}
        <div className="max-w-[1400px] mx-auto px-6 md:px-12 space-y-32">
          
          <div className="grid lg:grid-cols-2 gap-16 lg:gap-32 items-center reveal">
            <div>
              <span className="text-xs font-bold tracking-widest uppercase text-fuchsia-400 mb-6 block">02 — The Problem</span>
              <h2 className="text-3xl md:text-5xl font-display leading-tight mb-6 reveal-text">
                {project.story.problem}
              </h2>
            </div>
            <div>
              <span className="text-xs font-bold tracking-widest uppercase text-cyan-400 mb-6 block">03 — The Idea</span>
              <p className="text-xl font-light opacity-90 leading-relaxed mb-8 text-slate-300">{project.story.idea.text}</p>
              <div className="aspect-[4/3] overflow-hidden rounded-sm img-container shadow-[0_0_40px_rgba(64,201,255,0.15)] relative">
                <img src={project.story.idea.image} className="w-full h-full object-cover img-zoom" alt="The Idea" />
                <div className="absolute inset-0 bg-cyan-500/10 mix-blend-overlay"></div>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-12 gap-16 reveal border-y border-white/10 py-24 relative">
             <div className="absolute inset-0 bg-gradient-to-r from-fuchsia-900/5 to-cyan-900/5 pointer-events-none"></div>
            <div className="lg:col-span-4 relative z-10">
               <span className="text-xs font-bold tracking-widest uppercase text-fuchsia-400 mb-8 block">04 — Technology</span>
               <div className="flex flex-wrap gap-3">
                  {project.story.tech.map(t => (
                    <span key={t} className="px-5 py-2 border border-fuchsia-500/40 rounded-full text-xs font-mono uppercase tracking-wider hover:bg-fuchsia-500/20 hover:border-fuchsia-400 transition-all cursor-default shadow-[0_0_15px_rgba(232,28,255,0.1)]">{t}</span>
                  ))}
                </div>
            </div>
            <div className="lg:col-span-8 relative z-10">
               <span className="text-xs font-bold tracking-widest uppercase text-cyan-400 mb-8 block">05 — Features</span>
               <ul className="space-y-6">
                 {project.story.features.map((feat, i) => (
                   <li key={i} className="text-2xl md:text-4xl font-display border-b border-white/10 pb-6 hover:pl-4 transition-all hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-fuchsia-400 hover:to-cyan-400 cursor-default">
                     {feat}
                   </li>
                 ))}
               </ul>
            </div>
          </div>

          <div className="reveal">
            <span className="text-xs font-bold tracking-widest uppercase text-fuchsia-400 mb-8 block text-center">06 — How It Works</span>
            <div className="aspect-video overflow-hidden rounded-sm mb-8 bg-white/5 border border-fuchsia-500/30 img-container shadow-[0_0_50px_rgba(232,28,255,0.15)] relative group">
               <img src={project.story.architecture.image} className="w-full h-full object-contain img-zoom p-4 md:p-12 relative z-10" alt="Architecture" />
               <div className="absolute inset-0 bg-fuchsia-500/5 group-hover:bg-fuchsia-500/10 transition-colors"></div>
            </div>
            <p className="text-center text-lg font-mono opacity-80 max-w-3xl mx-auto text-slate-300">{project.story.architecture.text}</p>
          </div>

          {/* The Build / Screenshots */}
          <div className="reveal">
            <span className="text-xs font-bold tracking-widest uppercase text-cyan-400 mb-12 block">07 — The Build</span>
            <div className="grid md:grid-cols-12 gap-4">
              {project.story.screenshots.map((img, i) => (
                <div key={i} className={`img-container ${i === 0 ? 'md:col-span-12 aspect-[21/9]' : (i === 1 ? 'md:col-span-7 aspect-[4/3]' : 'md:col-span-5 aspect-[4/3]')} overflow-hidden rounded-sm border border-white/10 hover:border-cyan-500/50 transition-colors shadow-lg relative group`}>
                  <img src={img} className="w-full h-full object-cover img-zoom" alt={`Screenshot ${i+1}`} />
                  <div className="absolute inset-0 bg-cyan-900/20 opacity-0 group-hover:opacity-100 transition-opacity mix-blend-overlay"></div>
                </div>
              ))}
            </div>
          </div>

          {/* Final Reflection */}
          <div className="grid md:grid-cols-2 gap-16 reveal items-center bg-gradient-to-br from-fuchsia-900/30 to-blue-900/30 p-12 md:p-24 rounded-sm border border-fuchsia-500/40 shadow-[0_0_60px_rgba(232,28,255,0.15)] relative overflow-hidden">
            {/* Background glow in card */}
             <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/20 blur-[80px] rounded-full pointer-events-none"></div>
             
            <div className="relative z-10">
              <span className="text-xs font-bold tracking-widest uppercase text-fuchsia-400 mb-6 block">08 — Reflection</span>
              <h2 className="text-5xl font-display mb-8">WHAT I LEARNED</h2>
              <p className="text-xl font-light opacity-90 leading-relaxed italic text-fuchsia-50">
                "{project.story.learning}"
              </p>
            </div>
            <div className="flex flex-col gap-6 md:items-end relative z-10">
              <span className="text-xs font-bold tracking-widest uppercase text-cyan-400 block">09 — Project Links</span>
              <a href={project.story.github} className="text-3xl font-display uppercase flex items-center gap-4 hover:text-fuchsia-400 transition-colors group" data-cursor="CODE">
                Source Code <ExternalLink size={28} className="group-hover:scale-110 transition-transform"/>
              </a>
              <a href={project.story.demo} className="text-3xl font-display uppercase flex items-center gap-4 hover:text-cyan-400 transition-colors group" data-cursor="VIEW">
                Live Demo <ExternalLink size={28} className="group-hover:scale-110 transition-transform"/>
              </a>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

const ProjectsSection = ({ onOpenProject }) => {
  return (
    <section id="projects" data-theme="projects" className="py-32 md:py-48 px-6 md:px-12 section-marker relative">
      <div className="max-w-[1400px] mx-auto relative z-10">
        <span className="text-xs font-bold tracking-widest uppercase mb-20 block text-[var(--theme-accent)] reveal">03 — Selected Work</span>
        
        <div className="space-y-32">
          {portfolioData.projects.map((project, index) => (
            <div key={project.id} className="group relative cursor-pointer reveal" onClick={() => onOpenProject(project)} data-cursor="EXPLORE">
              <div className="relative aspect-[4/5] md:aspect-[21/9] overflow-hidden rounded-sm shadow-[0_20px_50px_rgba(217,70,239,0.1)] group-hover:shadow-[0_20px_80px_rgba(217,70,239,0.25)] transition-all duration-700 border border-white/5 group-hover:border-fuchsia-500/30">
                <img 
                  src={project.cover} 
                  alt={project.title} 
                  className="w-full h-full object-cover transform transition-transform duration-[2s] group-hover:scale-105 opacity-80 group-hover:opacity-100 grayscale group-hover:grayscale-0" 
                />
                <div className="absolute inset-0 bg-purple-900/50 group-hover:bg-transparent transition-colors duration-700"></div>
                {/* Colorful Glow Overlay on Hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-fuchsia-900/80 via-blue-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
              </div>
              
              {/* Floating Info Overlay */}
              <div className="absolute inset-0 z-20 flex flex-col justify-between p-8 md:p-16 pointer-events-none">
                <div className="overflow-hidden">
                  <span className="text-sm font-mono tracking-widest uppercase text-cyan-300 drop-shadow-md transform translate-y-full group-hover:translate-y-0 transition-transform duration-500 block font-bold">
                    {String(index + 1).padStart(2, '0')} — {project.subtitle}
                  </span>
                </div>
                <div>
                  <h2 className="text-6xl md:text-[8rem] font-display leading-[0.8] mix-blend-overlay group-hover:mix-blend-normal transition-all duration-700 text-white drop-shadow-[0_0_30px_rgba(217,70,239,0.6)]">
                    {project.title}
                  </h2>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const SkillsSection = () => {
  return (
    <section id="skills" data-theme="skills" className="py-32 md:py-48 px-6 md:px-12 section-marker overflow-hidden border-t border-slate-100 relative">
      {/* Background colorful elements for light theme */}
      <div className="absolute top-1/4 left-10 w-72 h-72 bg-emerald-400/10 blur-[100px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-10 w-96 h-96 bg-cyan-400/10 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-[1400px] mx-auto relative z-10">
        
        {/* Typographic Wall */}
        <div className="mb-48 reveal">
          <span className="text-xs font-bold tracking-widest uppercase mb-16 block text-[var(--theme-accent)]">04 — Things I Work With</span>
          <div className="flex flex-wrap items-baseline gap-x-8 gap-y-4 md:gap-x-12 md:gap-y-6 justify-center">
            {portfolioData.skills.map((skill, i) => (
              <span 
                key={i} 
                className={`font-display uppercase leading-[0.85] opacity-80 hover:opacity-100 transition-all duration-300 cursor-default hover:scale-105 ${skill.size.includes('text-transparent') ? skill.size : `${skill.size} hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-emerald-400 hover:to-cyan-500`}`} 
                data-cursor="SKILL"
              >
                {skill.name}
              </span>
            ))}
          </div>
        </div>

        {/* Currently Exploring (Floating Words) */}
        <div className="reveal">
          <span className="text-xs font-bold tracking-widest uppercase mb-16 block text-[var(--theme-accent-2)] md:text-right">05 — Currently Exploring</span>
          <div className="flex flex-col md:items-end gap-8 md:gap-4 relative">
            {portfolioData.learning.map((item, i) => (
              <div key={i} className="group relative cursor-default md:text-right" data-cursor="LEARNING">
                <h3 className="text-4xl md:text-7xl font-display uppercase text-outline group-hover:-webkit-text-stroke-transparent group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-cyan-500 group-hover:to-blue-600 transition-all duration-300 transform group-hover:-translate-x-4">
                  {item.topic}
                </h3>
                
                {/* Visual Tooltip */}
                <div className="md:absolute right-full top-1/2 md:-translate-y-1/2 mr-8 mt-4 md:mt-0 w-64 md:w-80 opacity-100 md:opacity-0 md:pointer-events-none group-hover:opacity-100 transition-all duration-500 z-50">
                  <div className="bg-white border border-cyan-500/30 p-3 rounded-sm shadow-[0_20px_50px_rgba(6,182,212,0.15)] rotate-0 md:-rotate-2 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-transparent pointer-events-none"></div>
                    <img src={item.img} alt={item.topic} className="w-full aspect-video object-cover mb-3 opacity-90 relative z-10" />
                    <p className="text-xs font-mono tracking-wider text-slate-800 uppercase relative z-10">{item.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};

const ArchiveSection = ({ onOpenImage }) => {
  return (
    <section id="archive" data-theme="archive" className="py-32 md:py-48 px-6 md:px-12 section-marker relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#0f0a1c] pointer-events-none z-0"></div>
      <div className="max-w-[1400px] mx-auto relative z-10">
        
        {/* Certificates Horizontal Archive */}
        <div className="mb-48 reveal">
          <span className="text-xs font-bold tracking-widest uppercase mb-16 block text-[var(--theme-accent)] drop-shadow-[0_0_10px_rgba(139,92,246,0.5)]">06 — Certificate Archive</span>
          
          <div className="flex overflow-x-auto gap-8 pb-12 snap-x snap-mandatory hide-scrollbar">
            {portfolioData.certificates.map(cert => (
              <div 
                key={`cert-${cert.id}`} 
                className="snap-start shrink-0 w-[85vw] md:w-[40vw] lg:w-[30vw] group cursor-pointer" 
                onClick={() => onOpenImage(cert.image)} 
                data-cursor="VIEW"
              >
                <div className="aspect-[4/3] overflow-hidden rounded-sm bg-white/5 border border-purple-500/20 mb-6 relative transform transition-all duration-500 group-hover:-translate-y-4 shadow-[0_10px_30px_rgba(0,0,0,0.5)] group-hover:shadow-[0_20px_50px_rgba(139,92,246,0.4)] group-hover:border-purple-400/60">
                  <img src={cert.image} alt={cert.title} className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity duration-500 grayscale group-hover:grayscale-0" />
                  <div className="absolute inset-0 bg-gradient-to-t from-purple-900/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                </div>
                <div>
                  <h4 className="text-xl font-display tracking-wider mb-2 text-white group-hover:text-purple-300 transition-colors drop-shadow-sm">{cert.title}</h4>
                  <div className="flex justify-between items-center text-xs font-mono opacity-80 text-fuchsia-200">
                    <span>{cert.issuer}</span>
                    <span className="bg-purple-900/50 px-2 py-1 rounded text-purple-200">{cert.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Milestones / Achievements Editorial */}
        <div className="reveal">
          <span className="text-xs font-bold tracking-widest uppercase mb-16 block text-[var(--theme-accent-2)] drop-shadow-[0_0_10px_rgba(244,63,94,0.5)]">07 — Milestones</span>
          <div className="space-y-32">
            {portfolioData.achievements.map((ach, i) => (
              <div key={`ach-${ach.id}`} className={`grid md:grid-cols-12 gap-8 md:gap-16 items-center reveal ${i % 2 !== 0 ? 'md:flex-row-reverse' : ''}`}>
                <div className={`md:col-span-5 ${i % 2 !== 0 ? 'md:order-2' : 'md:order-1'}`}>
                  <span className="text-sm font-mono tracking-widest text-pink-400 mb-4 block inline-block border border-pink-500/30 px-3 py-1 rounded-full">{ach.date}</span>
                  <h3 className="text-4xl md:text-5xl font-display mb-6 text-white drop-shadow-md">{ach.title}</h3>
                  <p className="font-light opacity-90 text-lg leading-relaxed text-gray-300">{ach.desc}</p>
                </div>
                <div className={`md:col-span-7 img-container cursor-pointer ${i % 2 !== 0 ? 'md:order-1' : 'md:order-2'} relative group`} onClick={() => onOpenImage(ach.image)}>
                  <div className="absolute inset-0 bg-pink-500/10 blur-[50px] opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                  <img src={ach.image} alt={ach.title} className="w-full aspect-[4/3] object-cover rounded-sm img-zoom grayscale group-hover:grayscale-0 shadow-[0_10px_40px_rgba(0,0,0,0.5)] group-hover:shadow-[0_20px_60px_rgba(244,63,94,0.3)] transition-all duration-700 border border-white/5 group-hover:border-pink-500/30 relative z-10" data-cursor="VIEW"/>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const GallerySection = ({ onOpenImage }) => {
  return (
    <section id="gallery" data-theme="gallery" className="py-32 px-6 md:px-12 section-marker relative overflow-hidden">
      {/* Cinematic dark background elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full max-w-[1000px] bg-amber-600/5 blur-[150px] rounded-full pointer-events-none"></div>

      <div className="max-w-[1400px] mx-auto relative z-10">
        <div className="mb-20 reveal">
          <span className="text-xs font-bold tracking-widest uppercase mb-4 block text-[var(--theme-accent)]">08 — Beyond the Code</span>
          <h2 className="text-5xl md:text-8xl font-display reveal-text drop-shadow-[0_0_30px_rgba(245,158,11,0.4)] text-white">MY LENS.</h2>
        </div>

        {/* Editorial Masonry Layout using CSS Columns */}
        <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
          {portfolioData.gallery.map((item, i) => (
            <div 
              key={i} 
              className="relative overflow-hidden group cursor-pointer reveal break-inside-avoid rounded-sm bg-white/5 border border-white/5 hover:border-amber-500/40 hover:shadow-[0_0_50px_rgba(245,158,11,0.25)] transition-all duration-500" 
              onClick={() => onOpenImage(item.img)}
              data-cursor="VIEW"
            >
              <img src={item.img} alt={item.caption} className="w-full h-auto object-cover transform transition-transform duration-[2s] group-hover:scale-105 grayscale group-hover:grayscale-0 opacity-70 group-hover:opacity-100" />
              <div className="absolute inset-0 bg-gradient-to-t from-orange-900/90 via-purple-900/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-6 pointer-events-none mix-blend-multiply"></div>
               <div className="absolute bottom-0 left-0 p-6 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10">
                <span className="font-mono text-xs uppercase tracking-widest text-amber-300 drop-shadow-md font-bold">{item.caption}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const ContactSection = () => {
  return (
    <section id="contact" data-theme="contact" className="min-h-screen flex flex-col justify-between px-6 md:px-12 pt-32 pb-8 section-marker relative overflow-hidden bg-animated-gradient">
      <div className="absolute inset-0 bg-black/40 mix-blend-overlay z-0 pointer-events-none"></div>
      
      <div className="flex-1 flex flex-col justify-center reveal max-w-[1400px] mx-auto w-full relative z-10">
        <span className="text-xs font-bold tracking-widest uppercase mb-8 block opacity-100 text-white drop-shadow-md">09 — Final Chapter</span>
        
        <h2 className="text-[12vw] md:text-[10rem] lg:text-[12rem] font-display leading-[0.8] mb-12 mix-blend-overlay reveal-text text-white">
          LET'S<br/>MAKE<br/>SOMETHING.
        </h2>
        
        <div className="flex flex-col gap-6 mt-8">
          <a href={`mailto:${portfolioData.profile.email}`} className="text-3xl md:text-5xl font-display text-white hover:text-yellow-300 transition-colors inline-block w-max drop-shadow-lg" data-cursor="EMAIL">
            {portfolioData.profile.email}
          </a>
          <div className="flex gap-8 items-center">
            <a href={portfolioData.profile.github} className="text-sm font-bold tracking-widest uppercase text-white hover:text-yellow-300 transition-colors flex items-center gap-2 drop-shadow-md bg-white/10 px-4 py-2 rounded-full backdrop-blur-sm border border-white/20" data-cursor="GITHUB">
              GitHub <ArrowRight size={16}/>
            </a>
            <a href={portfolioData.profile.linkedin} className="text-sm font-bold tracking-widest uppercase text-white hover:text-yellow-300 transition-colors flex items-center gap-2 drop-shadow-md bg-white/10 px-4 py-2 rounded-full backdrop-blur-sm border border-white/20" data-cursor="LINKEDIN">
              LinkedIn <ArrowRight size={16}/>
            </a>
          </div>
        </div>
      </div>

      <div className="w-full flex justify-between items-end text-[10px] md:text-xs font-mono tracking-widest uppercase text-white opacity-90 relative z-10 mt-20 max-w-[1400px] mx-auto drop-shadow-md">
        <span>Thanks for exploring.</span>
        <span>{portfolioData.profile.name} {portfolioData.profile.lastName} © 2026</span>
      </div>
    </section>
  );
};

const Lightbox = ({ image, onClose }) => {
  if (!image) return null;
  return (
    <div 
      className="fixed inset-0 z-[300] bg-black/95 flex items-center justify-center p-4 md:p-12 animate-in fade-in duration-300 backdrop-blur-xl"
      onClick={onClose}
    >
      <button className="absolute top-6 right-6 md:top-12 md:right-12 text-white/70 hover:text-white hover:rotate-90 transition-all z-10 p-2">
        <X size={32} />
      </button>
      <img src={image} className="max-w-full max-h-full object-contain shadow-[0_0_100px_rgba(255,255,255,0.1)] rounded-sm animate-in zoom-in-95 duration-500" alt="Fullscreen" />
    </div>
  );
};

export default function App() {
  const [activeProject, setActiveProject] = useState(null);
  const [lightboxImg, setLightboxImg] = useState(null);

  useScrollReveal();
  useThemeObserver();

  // Prevent scroll when modals are open
  useEffect(() => {
    if (activeProject || lightboxImg) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => { document.body.style.overflow = 'auto'; };
  }, [activeProject, lightboxImg]);

  return (
    <div className="relative w-full min-h-screen selection:bg-fuchsia-500/30 selection:text-white">
      {injectGlobalStyles()}
      <div className="noise-overlay"></div>
      
      {/* Global Animated Glow Behind Everything */}
      <div className="fixed inset-0 z-[-1] pointer-events-none overflow-hidden transition-opacity duration-1000 mix-blend-screen">
         <div className="absolute top-[-10%] left-[-10%] w-[40vw] h-[40vw] rounded-full opacity-30 filter blur-[120px] animate-[float-slow_15s_infinite] transition-colors duration-1000" style={{ backgroundColor: 'var(--theme-accent)' }}></div>
         <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] rounded-full opacity-20 filter blur-[140px] animate-[float-slow_20s_infinite_reverse] transition-colors duration-1000" style={{ backgroundColor: 'var(--theme-accent-2)' }}></div>
      </div>
      
      <Cursor />
      <Navbar />

      <main className="transition-opacity duration-1000 opacity-100">
        <HeroSection />
        <AboutSection />
        <JourneySection />
        <ProjectsSection onOpenProject={setActiveProject} />
        <SkillsSection />
        <ArchiveSection onOpenImage={setLightboxImg} />
        <GallerySection onOpenImage={setLightboxImg} />
        <ContactSection />
      </main>

      {activeProject && <ProjectCaseStudy project={activeProject} onClose={() => setActiveProject(null)} />}
      <Lightbox image={lightboxImg} onClose={() => setLightboxImg(null)} />
    </div>
  );
}